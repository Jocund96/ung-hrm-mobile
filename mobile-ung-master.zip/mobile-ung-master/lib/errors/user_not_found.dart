class UserNotFoundError extends Error {
  UserNotFoundError() : super();
}
