class AppNotInstalledError extends Error {
  AppNotInstalledError() : super();
}
