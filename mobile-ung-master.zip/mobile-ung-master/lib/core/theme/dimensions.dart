class Dimens {
  static const double appMargin = 20;
  static const double appRadius = 15;
  static const double loadingRadius30 = 30;
  static const double borderRadius = 6;
}
