abstract class JsonEncodable {
  Map<String, dynamic> toJson();
}
